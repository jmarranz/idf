// TransparentDialogDlg.cpp : implementation file
//MFC Transparent CDialog windows.

/* Copyright (C) 2002 by Nic Wilson  http://www.nicsoft.com.au
Written by Nic Wilson nicw@bigpond.net.au
All rights reserved

This is free software.
This code may be used in compiled form in any way you desire. This  
file may be redistributed unmodified by any means PROVIDING it is   
not sold for profit without the authors written consent, and   
providing that this notice and the authors name and all copyright   
notices remains intact. If the source code in this file is used in   
any  commercial application then a statement along the lines of   
Portions Copyright � 2002 Nic Wilson MUST be included in   
the startup banner, "About" dialog & printed documentation.   

No warrantee of any kind, expressed or implied, is included with this
software; use at your own risk, responsibility for damages (if any) to
anyone resulting from the use of this software rests entirely with the
user.

Release Date and Version:
Version: 1.0 December 2002



USAGE:

You should be able to use this demo as a skeleton application for your 
own project.

A standard CDialog MFC EXE application was created with the wizard and
apart from the standard  supplied code, the following functions were overridden.


	void OnClose() 
	Used to clean up some resources on exit.
	
	void OnPaint() 
	Used to paint the bimap into the region.

	void OnSize(UINT nType, int cx, int cy)
	Used to create the region and position and resize the dialog.

	void OnLButtonDown(UINT nFlags, CPoint point)
	To allow the dialog to be dragged by clicking anywhere.	


A button was created to allow the user to close the dialog.
A timer was  created to demonstrate auto closing after a period of time.

The image is a normal bmp file that is loaded by the app and ued to paint
the dialog.  TRANSPARENTCOLOR is defined in the dialog class header as bright
purple (RGB(255, 0, 255), but this could be changed to any colour you like.

The dialog window is auto sized to the size of the loaded bitmap then a region
created based on the transparent colour.  The dialog is then positioned in the 
centre of the current screen.   This was done as an example for those who want
to use this application as a splash windows.

The button serves no real purpose and was made a close button simply to demonstrate
using a button.

*/