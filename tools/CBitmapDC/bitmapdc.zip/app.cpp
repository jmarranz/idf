// app.cpp : Defines the entry point for the console application.
//

#include <afxwin.h>
#include <math.h>
#include <conio.h>
#include "memdc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static const char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

static CWinApp theApp;

#define signfactor(a) (( (a) >= 0) ? (+1) : (-1) )
#define iround(a)  ((int) ( (a) + signfactor(a) * 0.5 ))

int _tmain(int /*argc*/, TCHAR* /*argv*/[], TCHAR* /*envp*/[])
{
	// initialize MFC and print and error on failure
	VERIFY(AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0));
   
   const COLORREF crBack  = RGB(0xFF,0xFF,0x00);
   const COLORREF crPixel = RGB(0x00,0xFF,0x00);
   const COLORREF crText  = RGB(0x00,0x00,0xFF);   

   const double pi = 2.0*acos(0.0);
   
   const CSize size(200,200);
   CPoint pt(0, 0);

   CxMemDC dc(size);
   dc.FillSolidRect(0, 0, size.cx, size.cy, crBack);
   dc.SetTextColor(crText);
   dc.SetBkMode(TRANSPARENT);
   CFont* old = dc.SelectObject(CFont::FromHandle((HFONT)::GetStockObject(DEFAULT_GUI_FONT)));
   dc.TextOut(pt.x, pt.y, _T("Hello world!"));
   dc.SelectObject(old);
   for (double arg = 0.0, argstep = 2.0*pi/(double)size.cx; pt.x < size.cx; arg+=argstep, pt.x++)
   {
      pt.y = iround(sin(arg) * (double)size.cy / 2.0) + size.cy / 2;
      dc.SetPixel(pt, crPixel);
   }

   if (OpenClipboard(NULL))
   {
      EmptyClipboard();
      VERIFY(NULL != SetClipboardData(CF_BITMAP, dc.DetachBitmap()));
      CloseClipboard();
   }
   else
   {
      _tprintf(_T("Clipboard not available\n"));
   }

   _tprintf(_T("Done\n"));
	return EXIT_SUCCESS;
}
